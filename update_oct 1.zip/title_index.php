
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="ccs.png">
						</div>
						<div class="span8">

								<div class="title">
							<p class="chmsc">Don Mariano Marcos Memorial State University</p>
							<h3>

							<p>M - Learning</p>

							</h3>
						</div>

						</div>
							</div>

				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>College of Computer Science</p>
												<p>We Code to Innovate</p>

								</div>
						</div>
				</div>