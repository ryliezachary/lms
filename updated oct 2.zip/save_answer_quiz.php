
<pre>

    <?php
   //   print_r($_POST);
    ?>

</pre>

<?php
  include 'session.php';
  include 'sql_statements.php';

  $pretest=select_info_multiple_key("select * from quiz_question where
  quiz_id='".$_POST['quiz_id']."'");
  $ctr=0;
  if($pretest)
  {
      foreach($pretest as $p)
      {
        if($_POST[$p['quiz_question_id']]==$p['answer'])
        {
            $ctr++;
        }

      }
  }

  insert_update_delete("insert into student_class_quiz values('','".$_POST['class_quiz_id']."','".$session_id."','0','".$ctr."')");
  echo "insert into student_class_quiz values('','".$_POST['quiz_id']."','".$session_id."','0','".$ctr."')";
 header("Location:student_quiz_list.php?id=".$_GET['id']);
 echo "<br>Score ". $ctr;


?>