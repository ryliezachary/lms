<center>
		<footer>
		
		<p>Adaptive elearning for  the College of Computer Science,DMMMSU-SLUC</p>

		</footer>
</center>

